# K-Means Clustering

## Overview
This project demonstrates unsupervised learning using the **K-Means Clustering** algorithm.  
The goal is to group customers into clusters based on their similarities.

## Objective
Perform clustering with K-Means and evaluate the results using the **Elbow Method** and **Silhouette Score**.

## Tools Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## Dataset
Mall Customer Segmentation dataset  
[Download Dataset](https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python)

## Requirements
```
pip install pandas numpy matplotlib scikit-learn
```

## How to Run
1. Download and place `Mall_Customers.csv` in the same directory.
2. Run the script:
   ```bash
   python kmeans_clustering.py
   ```
3. View cluster visualization and evaluation metrics.

## Model Evaluation
- **Elbow Method**: Finds optimal number of clusters (K).  
- **Silhouette Score**: Measures cluster separation and cohesion.

## Output
- Optimal K value based on elbow curve.
- Clustered scatter plot with color-coded labels.
- Silhouette Score displayed.

## Author
Part of **AI & ML Internship Task 8** – Clustering with K-Means
