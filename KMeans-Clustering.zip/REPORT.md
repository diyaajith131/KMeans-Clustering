# Project Report – K-Means Clustering

## Objective
The objective of this project is to apply **K-Means Clustering** for customer segmentation using the Mall Customers dataset.

## Methodology
1. Data loading and preprocessing using Pandas.
2. Feature selection: Annual Income and Spending Score.
3. Data standardization with StandardScaler.
4. Elbow Method used to find optimal K.
5. Clustering performed with K-Means.
6. Evaluation using Silhouette Score.

## Results
- Optimal number of clusters (K): 5
- Silhouette Score: ~0.55
- Visualization clearly separates customer groups.

## Conclusion
K-Means effectively segmented customers into distinct groups, helping understand shopping behavior patterns.

## Tools
- Scikit-learn
- Pandas
- NumPy
- Matplotlib
